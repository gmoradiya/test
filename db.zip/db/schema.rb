# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20190917054735) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "actions", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "associates", force: :cascade do |t|
    t.string "associateable_id"
    t.string "associateable_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["associateable_id", "associateable_type"], name: "index_associates_on_associateable_id_and_associateable_type"
  end

  create_table "attribute_options", force: :cascade do |t|
    t.string "option_name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "audits", force: :cascade do |t|
    t.integer "auditable_id"
    t.string "auditable_type"
    t.integer "associated_id"
    t.string "associated_type"
    t.integer "user_id"
    t.string "user_type"
    t.string "username"
    t.string "action"
    t.text "audited_changes"
    t.integer "version", default: 0
    t.string "comment"
    t.string "remote_address"
    t.string "request_uuid"
    t.datetime "created_at"
    t.index ["associated_type", "associated_id"], name: "associated_index"
    t.index ["auditable_type", "auditable_id", "version"], name: "auditable_index"
    t.index ["created_at"], name: "index_audits_on_created_at"
    t.index ["request_uuid"], name: "index_audits_on_request_uuid"
    t.index ["user_id", "user_type"], name: "user_index"
  end

  create_table "brands", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id"
    t.index ["user_id"], name: "index_brands_on_user_id"
  end

  create_table "categories", force: :cascade do |t|
    t.string "title"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_categories_on_user_id"
  end

  create_table "cemails", force: :cascade do |t|
    t.string "to"
    t.string "cc"
    t.string "bcc"
    t.string "subject"
    t.string "content"
    t.string "cemailable_type"
    t.bigint "cemailable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["cemailable_type", "cemailable_id"], name: "index_cemails_on_cemailable_type_and_cemailable_id"
  end

  create_table "ckeditor_assets", force: :cascade do |t|
    t.string "data_file_name", null: false
    t.string "data_content_type"
    t.integer "data_file_size"
    t.string "type", limit: 30
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["type"], name: "index_ckeditor_assets_on_type"
  end

  create_table "clients", force: :cascade do |t|
    t.string "company_name"
    t.string "lead_no"
    t.string "phone_no"
    t.string "company_email"
    t.string "lead_status"
    t.bigint "user_id"
    t.text "description"
    t.string "street_address"
    t.string "city"
    t.string "state"
    t.string "zip_code"
    t.string "company_url"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.index ["deleted_at"], name: "index_clients_on_deleted_at"
    t.index ["user_id"], name: "index_clients_on_user_id"
  end

  create_table "comments", force: :cascade do |t|
    t.string "content"
    t.string "commentable_type"
    t.bigint "commentable_id"
    t.bigint "user_id"
    t.string "attachment"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.index ["commentable_type", "commentable_id"], name: "index_comments_on_commentable_type_and_commentable_id"
    t.index ["deleted_at"], name: "index_comments_on_deleted_at"
    t.index ["user_id"], name: "index_comments_on_user_id"
  end

  create_table "companies", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "domain_url"
    t.string "email"
    t.string "street_address"
    t.string "city"
    t.string "state"
    t.string "zip_code"
    t.string "work_phone"
    t.string "website_url"
    t.string "big_logo"
    t.string "small_logo"
    t.string "fevicon_logo"
    t.string "description"
  end

  create_table "contacts", force: :cascade do |t|
    t.string "first_name"
    t.string "last_name"
    t.string "phone_no"
    t.boolean "portal_invitation"
    t.boolean "is_primary"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.string "profile_picture"
    t.index ["email"], name: "index_contacts_on_email", unique: true
    t.index ["reset_password_token"], name: "index_contacts_on_reset_password_token", unique: true
  end

  create_table "custom_values", force: :cascade do |t|
    t.bigint "field_id"
    t.string "value"
    t.string "valuable_type"
    t.bigint "valuable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["field_id"], name: "index_custom_values_on_field_id"
    t.index ["valuable_type", "valuable_id"], name: "index_custom_values_on_valuable_type_and_valuable_id"
  end

  create_table "delayed_jobs", force: :cascade do |t|
    t.integer "priority", default: 0, null: false
    t.integer "attempts", default: 0, null: false
    t.text "handler", null: false
    t.text "last_error"
    t.datetime "run_at"
    t.datetime "locked_at"
    t.datetime "failed_at"
    t.string "locked_by"
    t.string "queue"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["priority", "run_at"], name: "delayed_jobs_priority"
  end

  create_table "directories", force: :cascade do |t|
    t.string "name"
    t.string "directoriable_type"
    t.bigint "directoriable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.string "resourcable_type"
    t.bigint "resourcable_id"
    t.index ["deleted_at"], name: "index_directories_on_deleted_at"
    t.index ["directoriable_type", "directoriable_id"], name: "index_directories_on_directoriable_type_and_directoriable_id"
    t.index ["resourcable_type", "resourcable_id"], name: "index_directories_on_resourcable_type_and_resourcable_id"
  end

  create_table "document_documentables", force: :cascade do |t|
    t.bigint "document_id"
    t.string "documentable_type"
    t.bigint "documentable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "resourcable_type"
    t.bigint "resourcable_id"
    t.index ["document_id"], name: "index_document_documentables_on_document_id"
    t.index ["documentable_type", "documentable_id"], name: "document_documentable"
    t.index ["resourcable_type", "resourcable_id"], name: "documentables_resourcable_index"
  end

  create_table "documents", force: :cascade do |t|
    t.string "attachment"
    t.string "resourcable_type"
    t.bigint "resourcable_id"
    t.bigint "directory_id"
    t.string "title"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.index ["deleted_at"], name: "index_documents_on_deleted_at"
    t.index ["directory_id"], name: "index_documents_on_directory_id"
    t.index ["resourcable_type", "resourcable_id"], name: "index_documents_on_resourcable_type_and_resourcable_id"
  end

  create_table "email_templetes", force: :cascade do |t|
    t.string "name"
    t.string "subject"
    t.string "content"
    t.string "attachment"
    t.bigint "user_id"
    t.bigint "template_dir_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["template_dir_id"], name: "index_email_templetes_on_template_dir_id"
    t.index ["user_id"], name: "index_email_templetes_on_user_id"
  end

  create_table "emails", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "field_picklist_values", force: :cascade do |t|
    t.bigint "field_id"
    t.string "value"
    t.integer "position"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_system", default: false
    t.index ["field_id"], name: "index_field_picklist_values_on_field_id"
  end

  create_table "fields", force: :cascade do |t|
    t.string "name"
    t.string "label"
    t.string "column_type"
    t.bigint "klass_id"
    t.integer "position"
    t.integer "head_position"
    t.string "placeholder"
    t.integer "min_length"
    t.integer "max_length"
    t.string "default_value"
    t.boolean "required", default: false
    t.boolean "quick_create", default: false
    t.boolean "key_field_view", default: false
    t.boolean "header_view", default: false
    t.boolean "mass_edit", default: false
    t.boolean "deletable", default: true
    t.boolean "system_field", default: false
    t.bigint "group_id"
    t.boolean "custom", default: true
    t.boolean "reference", default: false
    t.string "reference_klass", default: ""
    t.string "reference_key", default: ""
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "have_custom_value", default: false
    t.datetime "deleted_at"
    t.index ["deleted_at"], name: "index_fields_on_deleted_at"
    t.index ["group_id"], name: "index_fields_on_group_id"
    t.index ["klass_id"], name: "index_fields_on_klass_id"
  end

  create_table "groups", force: :cascade do |t|
    t.string "name"
    t.string "label"
    t.bigint "klass_id"
    t.integer "position"
    t.string "hint"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "default", default: false
    t.datetime "deleted_at"
    t.index ["deleted_at"], name: "index_groups_on_deleted_at"
    t.index ["klass_id"], name: "index_groups_on_klass_id"
  end

  create_table "import_data_csvs", force: :cascade do |t|
    t.bigint "user_id"
    t.bigint "document_id"
    t.jsonb "data"
    t.bigint "klass_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["document_id"], name: "index_import_data_csvs_on_document_id"
    t.index ["klass_id"], name: "index_import_data_csvs_on_klass_id"
    t.index ["user_id"], name: "index_import_data_csvs_on_user_id"
  end

  create_table "inventories", force: :cascade do |t|
    t.bigint "inventory_group_id"
    t.bigint "user_id"
    t.float "buy_price"
    t.float "sell_price"
    t.string "image"
    t.string "barcode"
    t.boolean "is_taxable", default: false
    t.string "sku"
    t.integer "available_quantity", default: 0
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "unit_id"
    t.boolean "returnable", default: false
    t.boolean "is_service", default: false
    t.integer "reorder_level", default: 0
    t.integer "upc", default: 0
    t.integer "ean", default: 0
    t.string "name"
    t.bigint "brand_id"
    t.bigint "merchant_id"
    t.bigint "category_id"
    t.bigint "subcategory_id"
    t.boolean "active", default: true
    t.integer "length"
    t.integer "height"
    t.integer "width"
    t.float "weight"
    t.string "mpn"
    t.string "sales_description"
    t.string "isbn"
    t.float "available_value", default: 0.0
    t.integer "initial_quantity", default: 0
    t.float "tax", default: 0.0
    t.string "purchase_description"
    t.float "initial_value", default: 0.0
    t.boolean "is_purchasable", default: true
    t.boolean "is_saleable", default: true
    t.boolean "is_trackable", default: true
    t.index ["brand_id"], name: "index_inventories_on_brand_id"
    t.index ["category_id"], name: "index_inventories_on_category_id"
    t.index ["inventory_group_id"], name: "index_inventories_on_inventory_group_id"
    t.index ["merchant_id"], name: "index_inventories_on_merchant_id"
    t.index ["subcategory_id"], name: "index_inventories_on_subcategory_id"
    t.index ["unit_id"], name: "index_inventories_on_unit_id"
    t.index ["user_id"], name: "index_inventories_on_user_id"
  end

  create_table "inventory_group_options", force: :cascade do |t|
    t.bigint "attribute_option_id"
    t.bigint "inventory_group_id"
    t.string "options", default: [], array: true
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["attribute_option_id"], name: "index_inventory_group_options_on_attribute_option_id"
    t.index ["inventory_group_id"], name: "index_inventory_group_options_on_inventory_group_id"
  end

  create_table "inventory_groups", force: :cascade do |t|
    t.string "name"
    t.bigint "category_id"
    t.bigint "subcategory_id"
    t.bigint "user_id"
    t.string "description"
    t.boolean "none_inevntory", default: false
    t.boolean "active", default: true
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "multiple_inventories", default: false
    t.boolean "is_taxable", default: true
    t.bigint "unit_id"
    t.boolean "returnable", default: false
    t.boolean "is_service", default: false
    t.string "image"
    t.bigint "brand_id"
    t.bigint "merchant_id"
    t.index ["brand_id"], name: "index_inventory_groups_on_brand_id"
    t.index ["category_id"], name: "index_inventory_groups_on_category_id"
    t.index ["merchant_id"], name: "index_inventory_groups_on_merchant_id"
    t.index ["subcategory_id"], name: "index_inventory_groups_on_subcategory_id"
    t.index ["unit_id"], name: "index_inventory_groups_on_unit_id"
    t.index ["user_id"], name: "index_inventory_groups_on_user_id"
  end

  create_table "invoice_inventories", force: :cascade do |t|
    t.integer "qty", default: 0
    t.float "rate", default: 0.0
    t.float "tax", default: 0.0
    t.float "amount", default: 0.0
    t.string "description"
    t.bigint "invoice_id"
    t.bigint "inventory_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["inventory_id"], name: "index_invoice_inventories_on_inventory_id"
    t.index ["invoice_id"], name: "index_invoice_inventories_on_invoice_id"
  end

  create_table "invoice_pdfs", force: :cascade do |t|
    t.bigint "invoice_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["invoice_id"], name: "index_invoice_pdfs_on_invoice_id"
  end

  create_table "invoice_taxes", force: :cascade do |t|
    t.string "name"
    t.float "tax_rate"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "invoices", force: :cascade do |t|
    t.bigint "client_id"
    t.string "invoice_number"
    t.string "billing_address"
    t.string "terms"
    t.string "email"
    t.date "invoice_date"
    t.date "due_date"
    t.string "msg_on_invoice"
    t.string "msg_on_statement"
    t.bigint "sales_person_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.string "attachment"
    t.string "invoice_no"
    t.string "cc"
    t.string "bcc"
    t.index ["client_id"], name: "index_invoices_on_client_id"
    t.index ["deleted_at"], name: "index_invoices_on_deleted_at"
    t.index ["sales_person_id"], name: "index_invoices_on_sales_person_id"
  end

  create_table "invoices_products", id: false, force: :cascade do |t|
    t.bigint "invoice_id", null: false
    t.bigint "product_id", null: false
  end

  create_table "klasses", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "label"
  end

  create_table "lead_client_contacts", force: :cascade do |t|
    t.bigint "contact_id"
    t.string "contactable_type"
    t.bigint "contactable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["contact_id"], name: "index_lead_client_contacts_on_contact_id"
    t.index ["contactable_type", "contactable_id"], name: "lead_client_contactable_index"
  end

  create_table "leads", force: :cascade do |t|
    t.string "company_name"
    t.string "lead_no"
    t.string "phone_no"
    t.string "company_email"
    t.string "lead_status"
    t.bigint "user_id"
    t.text "description", default: ""
    t.string "street_address"
    t.string "city"
    t.string "state"
    t.string "zip_code"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.index ["deleted_at"], name: "index_leads_on_deleted_at"
    t.index ["user_id"], name: "index_leads_on_user_id"
  end

  create_table "merchants", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id"
    t.index ["user_id"], name: "index_merchants_on_user_id"
  end

  create_table "messages", force: :cascade do |t|
    t.string "title"
    t.string "category"
    t.string "priority"
    t.string "status"
    t.string "description"
    t.string "messageable_type"
    t.bigint "messageable_id"
    t.string "resourcable_type"
    t.bigint "resourcable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["messageable_type", "messageable_id"], name: "index_messages_on_messageable_type_and_messageable_id"
    t.index ["resourcable_type", "resourcable_id"], name: "index_messages_on_resourcable_type_and_resourcable_id"
  end

  create_table "module_numbers", force: :cascade do |t|
    t.bigint "klass_id"
    t.string "module_prefix"
    t.string "sequence_start"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["klass_id"], name: "index_module_numbers_on_klass_id"
  end

  create_table "notes", force: :cascade do |t|
    t.string "content"
    t.string "noteable_type"
    t.string "noteable_id"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.string "attachment"
    t.index ["deleted_at"], name: "index_notes_on_deleted_at"
    t.index ["noteable_id", "noteable_type"], name: "index_notes_on_noteable_id_and_noteable_type"
    t.index ["user_id"], name: "index_notes_on_user_id"
  end

  create_table "payments", force: :cascade do |t|
    t.bigint "invoice_id"
    t.boolean "successful", default: false
    t.binary "response"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["invoice_id"], name: "index_payments_on_invoice_id"
  end

  create_table "permissions", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "products", force: :cascade do |t|
    t.string "product_name"
    t.string "available"
    t.string "unit_price"
    t.string "purchase_cost"
    t.string "qty_stock"
    t.string "description"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_products_on_user_id"
  end

  create_table "project_assignees", force: :cascade do |t|
    t.bigint "project_id"
    t.bigint "user_id"
    t.string "email"
    t.string "title"
    t.string "company"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["project_id"], name: "index_project_assignees_on_project_id"
    t.index ["user_id"], name: "index_project_assignees_on_user_id"
  end

  create_table "project_contacts", force: :cascade do |t|
    t.bigint "project_id"
    t.bigint "contact_id"
    t.bigint "client_id"
    t.boolean "status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["client_id"], name: "index_project_contacts_on_client_id"
    t.index ["contact_id"], name: "index_project_contacts_on_contact_id"
    t.index ["project_id"], name: "index_project_contacts_on_project_id"
  end

  create_table "project_documents", force: :cascade do |t|
    t.string "attachment"
    t.bigint "project_id"
    t.string "resourcable_type"
    t.bigint "resourcable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["project_id"], name: "index_project_documents_on_project_id"
    t.index ["resourcable_type", "resourcable_id"], name: "index_project_documents_on_resourcable_type_and_resourcable_id"
  end

  create_table "project_users", force: :cascade do |t|
    t.bigint "project_id"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "status"
    t.index ["project_id"], name: "index_project_users_on_project_id"
    t.index ["user_id"], name: "index_project_users_on_user_id"
  end

  create_table "projects", force: :cascade do |t|
    t.string "name"
    t.string "status"
    t.date "start_date"
    t.date "end_date"
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.bigint "user_id"
    t.bigint "client_id"
    t.index ["client_id"], name: "index_projects_on_client_id"
    t.index ["deleted_at"], name: "index_projects_on_deleted_at"
    t.index ["user_id"], name: "index_projects_on_user_id"
  end

  create_table "role_permissions", force: :cascade do |t|
    t.bigint "role_id"
    t.bigint "action_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "klass_id"
    t.index ["action_id"], name: "index_role_permissions_on_action_id"
    t.index ["klass_id"], name: "index_role_permissions_on_klass_id"
    t.index ["role_id"], name: "index_role_permissions_on_role_id"
  end

  create_table "roles", force: :cascade do |t|
    t.string "name"
    t.string "resource_type"
    t.bigint "resource_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["name", "resource_type", "resource_id"], name: "index_roles_on_name_and_resource_type_and_resource_id"
    t.index ["resource_type", "resource_id"], name: "index_roles_on_resource_type_and_resource_id"
  end

  create_table "sessions", force: :cascade do |t|
    t.string "session_id", null: false
    t.text "data"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["session_id"], name: "index_sessions_on_session_id", unique: true
    t.index ["updated_at"], name: "index_sessions_on_updated_at"
  end

  create_table "stock_adjustment_reasons", force: :cascade do |t|
    t.string "reason"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "active", default: true
  end

  create_table "stock_adjustments", force: :cascade do |t|
    t.bigint "stock_adjustment_reason_id"
    t.bigint "inventory_id"
    t.date "date"
    t.integer "adjustment_type", default: 0
    t.string "reference_no"
    t.float "new_quantity_on_hand"
    t.float "quantity_adjusted"
    t.float "new_value", default: 0.0
    t.float "value_adjusted", default: 0.0
    t.string "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.float "current_value"
    t.integer "current_quantity"
    t.bigint "invoice_inventory_id"
    t.index ["inventory_id"], name: "index_stock_adjustments_on_inventory_id"
    t.index ["invoice_inventory_id"], name: "index_stock_adjustments_on_invoice_inventory_id"
    t.index ["stock_adjustment_reason_id"], name: "index_stock_adjustments_on_stock_adjustment_reason_id"
  end

  create_table "subcategories", force: :cascade do |t|
    t.string "title"
    t.bigint "category_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["category_id"], name: "index_subcategories_on_category_id"
  end

  create_table "tasks", force: :cascade do |t|
    t.string "title"
    t.string "note"
    t.string "type_task"
    t.datetime "due_to"
    t.datetime "email_reminder"
    t.bigint "user_id"
    t.string "taskable_type"
    t.string "taskable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "attachment"
    t.datetime "deleted_at"
    t.boolean "completed", default: false
    t.index ["deleted_at"], name: "index_tasks_on_deleted_at"
    t.index ["taskable_type", "taskable_id"], name: "index_tasks_on_taskable_type_and_taskable_id"
    t.index ["user_id"], name: "index_tasks_on_user_id"
  end

  create_table "template_dirs", force: :cascade do |t|
    t.bigint "user_id"
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_template_dirs_on_user_id"
  end

  create_table "ticket_contacts", force: :cascade do |t|
    t.bigint "contact_id"
    t.bigint "ticket_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["contact_id"], name: "index_ticket_contacts_on_contact_id"
    t.index ["ticket_id"], name: "index_ticket_contacts_on_ticket_id"
  end

  create_table "ticket_users", force: :cascade do |t|
    t.bigint "user_id"
    t.bigint "ticket_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["ticket_id"], name: "index_ticket_users_on_ticket_id"
    t.index ["user_id"], name: "index_ticket_users_on_user_id"
  end

  create_table "tickets", force: :cascade do |t|
    t.string "category"
    t.string "priority"
    t.string "title"
    t.string "status"
    t.string "description"
    t.string "ticket_no"
    t.string "attachment"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "ticketable_type"
    t.bigint "ticketable_id"
    t.datetime "deleted_at"
    t.index ["deleted_at"], name: "index_tickets_on_deleted_at"
    t.index ["ticketable_type", "ticketable_id"], name: "index_tickets_on_ticketable_type_and_ticketable_id"
  end

  create_table "units", force: :cascade do |t|
    t.string "messure"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "unreads", force: :cascade do |t|
    t.string "unreadable_type"
    t.bigint "unreadable_id"
    t.string "resourcable_type"
    t.bigint "resourcable_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["resourcable_type", "resourcable_id"], name: "index_unreads_on_resourcable_type_and_resourcable_id"
    t.index ["unreadable_type", "unreadable_id"], name: "index_unreads_on_unreadable_type_and_unreadable_id"
  end

  create_table "user_permissions", force: :cascade do |t|
    t.bigint "user_id"
    t.jsonb "permissions"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_user_permissions_on_user_id"
  end

  create_table "users", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "first_name", default: "", null: false
    t.string "last_name", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "admin", default: false
    t.datetime "deleted_at"
    t.jsonb "ms_azure_token"
    t.string "profile_picture"
    t.string "phone_no"
    t.string "google_code"
    t.string "google_access_token"
    t.string "google_refresh_token"
    t.text "signature"
    t.string "google_email"
    t.datetime "google_token_expired_at"
    t.index ["deleted_at"], name: "index_users_on_deleted_at"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  end

  create_table "users_roles", id: false, force: :cascade do |t|
    t.bigint "user_id"
    t.bigint "role_id"
    t.index ["role_id"], name: "index_users_roles_on_role_id"
    t.index ["user_id", "role_id"], name: "index_users_roles_on_user_id_and_role_id"
    t.index ["user_id"], name: "index_users_roles_on_user_id"
  end

  create_table "work_flow_conditions", force: :cascade do |t|
    t.bigint "field_id"
    t.string "comparison"
    t.string "value"
    t.bigint "work_flow_id"
    t.string "condition_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["field_id"], name: "index_work_flow_conditions_on_field_id"
    t.index ["work_flow_id"], name: "index_work_flow_conditions_on_work_flow_id"
  end

  create_table "work_flows", force: :cascade do |t|
    t.string "name"
    t.text "description"
    t.bigint "klass_id"
    t.boolean "status"
    t.string "callback"
    t.boolean "reccuring"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["klass_id"], name: "index_work_flows_on_klass_id"
  end

  add_foreign_key "brands", "users"
  add_foreign_key "categories", "users"
  add_foreign_key "clients", "users"
  add_foreign_key "comments", "users"
  add_foreign_key "custom_values", "fields"
  add_foreign_key "document_documentables", "documents"
  add_foreign_key "documents", "directories"
  add_foreign_key "email_templetes", "template_dirs"
  add_foreign_key "email_templetes", "users"
  add_foreign_key "field_picklist_values", "fields"
  add_foreign_key "fields", "groups"
  add_foreign_key "fields", "klasses"
  add_foreign_key "groups", "klasses"
  add_foreign_key "import_data_csvs", "documents"
  add_foreign_key "import_data_csvs", "klasses"
  add_foreign_key "import_data_csvs", "users"
  add_foreign_key "inventories", "brands"
  add_foreign_key "inventories", "categories"
  add_foreign_key "inventories", "inventory_groups"
  add_foreign_key "inventories", "merchants"
  add_foreign_key "inventories", "subcategories"
  add_foreign_key "inventories", "units"
  add_foreign_key "inventories", "users"
  add_foreign_key "inventory_group_options", "attribute_options"
  add_foreign_key "inventory_group_options", "inventory_groups"
  add_foreign_key "inventory_groups", "brands"
  add_foreign_key "inventory_groups", "categories"
  add_foreign_key "inventory_groups", "merchants"
  add_foreign_key "inventory_groups", "subcategories"
  add_foreign_key "inventory_groups", "units"
  add_foreign_key "inventory_groups", "users"
  add_foreign_key "invoice_inventories", "inventories"
  add_foreign_key "invoice_inventories", "invoices"
  add_foreign_key "invoices", "users", column: "sales_person_id"
  add_foreign_key "lead_client_contacts", "contacts"
  add_foreign_key "leads", "users"
  add_foreign_key "merchants", "users"
  add_foreign_key "module_numbers", "klasses"
  add_foreign_key "payments", "invoices"
  add_foreign_key "products", "users"
  add_foreign_key "project_assignees", "projects"
  add_foreign_key "project_assignees", "users"
  add_foreign_key "project_contacts", "clients"
  add_foreign_key "project_contacts", "contacts"
  add_foreign_key "project_contacts", "projects"
  add_foreign_key "project_documents", "projects"
  add_foreign_key "project_users", "projects"
  add_foreign_key "project_users", "users"
  add_foreign_key "projects", "clients"
  add_foreign_key "projects", "users"
  add_foreign_key "role_permissions", "actions"
  add_foreign_key "role_permissions", "roles"
  add_foreign_key "stock_adjustments", "inventories"
  add_foreign_key "stock_adjustments", "invoice_inventories"
  add_foreign_key "stock_adjustments", "stock_adjustment_reasons"
  add_foreign_key "subcategories", "categories"
  add_foreign_key "tasks", "users"
  add_foreign_key "template_dirs", "users"
  add_foreign_key "ticket_contacts", "contacts"
  add_foreign_key "ticket_contacts", "tickets"
  add_foreign_key "ticket_users", "tickets"
  add_foreign_key "ticket_users", "users"
  add_foreign_key "user_permissions", "users"
  add_foreign_key "work_flow_conditions", "fields"
  add_foreign_key "work_flow_conditions", "work_flows"
  add_foreign_key "work_flows", "klasses"
end
